const GEMINI_API_KEY = process.env.NEXT_PUBLIC_GEMINI_API_KEY || '';

interface AdVariation {
  text: string;
  platform: string;
}

export async function generateAdCopy(
  description: string,
  platform: string,
  language: 'ar' | 'en'
): Promise<AdVariation[]> {
  if (!GEMINI_API_KEY || GEMINI_API_KEY === 'your_gemini_api_key_here') {
    throw new Error('Gemini API key not configured');
  }

  const prompt = language === 'ar'
    ? `أنشئ 3 نسخ إعلانية مختلفة ومختصرة باللغة العربية الفصحى لمنصة ${platform} عن المنتج/الخدمة التالية: "${description}"

متطلبات كل نسخة:
- جذابة وقصيرة (30-50 كلمة)
- مناسبة لمنصة ${platform}
- تحتوي على دعوة للعمل (Call to Action)
- لغة عربية فصحى سهلة

أعد النتيجة كـ JSON فقط بدون أي نص إضافي:
[
  {"text": "النسخة الأولى هنا"},
  {"text": "النسخة الثانية هنا"},
  {"text": "النسخة الثالثة هنا"}
]`
    : `Create 3 different catchy ad copies in English for ${platform} about: "${description}"

Requirements for each copy:
- Catchy and concise (30-50 words)
- Suitable for ${platform}
- Include a call to action
- Professional marketing tone

Return ONLY JSON without any additional text:
[
  {"text": "First copy here"},
  {"text": "Second copy here"},
  {"text": "Third copy here"}
]`;

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.8,
          maxOutputTokens: 1024
        }
      })
    }
  );

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(`Gemini API error: ${response.status} - ${errorData.error?.message || 'Unknown error'}`);
  }

  const data = await response.json();
  const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';

  // Extract JSON from response
  try {
    // Try to find JSON array in the response
    const jsonMatch = text.match(/\[[\s\S]*?\]/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (Array.isArray(parsed) && parsed.length === 3) {
        return parsed.map((item: any) => ({
          text: item.text || item.ad || item.copy || String(item),
          platform
        }));
      }
    }

    // Fallback: try to parse the whole text
    const parsed = JSON.parse(text);
    if (Array.isArray(parsed)) {
      return parsed.map((item: any) => ({
        text: item.text || item.ad || item.copy || String(item),
        platform
      }));
    }
  } catch (e) {
    console.error('Failed to parse JSON, using fallback parsing');
  }

  // Fallback: split by newlines and clean up
  const lines = text.split('
')
    .map(line => line.trim())
    .filter(line => line.length > 10 && !line.startsWith('[') && !line.startsWith(']') && !line.startsWith('{'))
    .slice(0, 3);

  if (lines.length >= 3) {
    return lines.map(text => ({ text, platform }));
  }

  // Ultimate fallback
  return [
    { text: language === 'ar' ? `اكتشف ${description} الآن!` : `Discover ${description} now!`, platform },
    { text: language === 'ar' ? `لا تفوت فرصة ${description}` : `Don't miss out on ${description}`, platform },
    { text: language === 'ar' ? `جرب ${description} اليوم` : `Try ${description} today`, platform }
  ];
}