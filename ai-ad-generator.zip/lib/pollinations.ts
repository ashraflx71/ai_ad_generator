export function generateImageUrl(description: string, platform: string): string {
  const platformStyle = {
    facebook: 'social media post, square format',
    instagram: 'Instagram post, aesthetic, modern',
    tiktok: 'TikTok style, trendy, vertical',
    twitter: 'Twitter/X post, clean, professional'
  };

  const style = platformStyle[platform as keyof typeof platformStyle] || 'social media ad';

  const prompt = `Professional advertisement image: ${description}. ${style}. High quality, modern design, clean background, no text overlay, commercial photography style, vibrant colors`;

  const encodedPrompt = encodeURIComponent(prompt);

  // Add seed for variety
  const seed = Math.floor(Math.random() * 1000000);

  return `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1024&height=1024&nologo=true&seed=${seed}`;
}