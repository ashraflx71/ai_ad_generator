'use client';

import { LanguageProvider } from '@/components/LanguageContext';
import AdGenerator from '@/components/AdGenerator';
import LanguageToggle from '@/components/LanguageToggle';
import Disclaimer from '@/components/Disclaimer';

export default function Home() {
  return (
    <LanguageProvider>
      <main className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <LanguageToggle />
          <AdGenerator />
          <Disclaimer />
        </div>
      </main>
    </LanguageProvider>
  );
}