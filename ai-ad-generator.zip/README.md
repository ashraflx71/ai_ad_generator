# AI Ad Generator - منشئ إعلانات ذكي

A bilingual (Arabic/English) AI-powered ad generator built with Next.js 14.

## Features
- ✅ Bilingual interface (Arabic/English) with RTL support
- ✅ AI text generation using Google Gemini API
- ✅ AI image generation using Pollinations.ai
- ✅ 3 ad copy variations per generation
- ✅ Copy to clipboard functionality
- ✅ Image download
- ✅ Local history (localStorage)
- ✅ Responsive design

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Copy `.env.local.example` to `.env.local` and add your Gemini API key:
   ```bash
   cp .env.local.example .env.local
   ```

3. Get your free API key from [Google AI Studio](https://aistudio.google.com/app/apikey)

4. Run the development server:
   ```bash
   npm run dev
   ```

5. Open [http://localhost:3000](http://localhost:3000)

## Deploy

Deploy to Vercel:
```bash
npm install -g vercel
vercel
```

## Legal Disclaimer
This site uses AI to generate ad content. Users are responsible for final content. No guarantee on ad results.