'use client';

import { useState, useEffect } from 'react';
import { useLanguage } from './LanguageContext';
import { generateAdCopy } from '@/lib/gemini';
import { generateImageUrl } from '@/lib/pollinations';

interface AdVariation {
  text: string;
  platform: string;
}

interface GeneratedAd {
  id: string;
  variations: AdVariation[];
  imageUrl: string;
  timestamp: number;
  productDescription: string;
}

export default function AdGenerator() {
  const { language, t, isRTL } = useLanguage();
  const [description, setDescription] = useState('');
  const [platform, setPlatform] = useState('instagram');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<GeneratedAd | null>(null);
  const [history, setHistory] = useState<GeneratedAd[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Load history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('adHistory');
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error('Failed to load history');
      }
    }
  }, []);

  // Save history to localStorage
  const saveToHistory = (ad: GeneratedAd) => {
    const newHistory = [ad, ...history].slice(0, 10);
    setHistory(newHistory);
    localStorage.setItem('adHistory', JSON.stringify(newHistory));
  };

  const handleGenerate = async () => {
    if (!description.trim()) return;

    // Check for API key
    const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
    if (!apiKey || apiKey === 'your_gemini_api_key_here') {
      setError(t('errorNoKey'));
      return;
    }

    setLoading(true);
    setError('');
    setResult(null);

    try {
      // Generate 3 ad variations
      const variations = await generateAdCopy(description, platform, language);

      // Generate image
      const imageUrl = generateImageUrl(description, platform);

      const newAd: GeneratedAd = {
        id: Date.now().toString(),
        variations,
        imageUrl,
        timestamp: Date.now(),
        productDescription: description
      };

      setResult(newAd);
      saveToHistory(newAd);
    } catch (err) {
      setError(t('error'));
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    });
  };

  const downloadImage = async (url: string, filename: string) => {
    try {
      const response = await fetch(url);
      const blob = await response.blob();
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);
    } catch (err) {
      console.error('Failed to download image');
    }
  };

  const loadFromHistory = (ad: GeneratedAd) => {
    setResult(ad);
    setDescription(ad.productDescription);
  };

  return (
    <div className={`space-y-8 ${isRTL ? 'rtl' : 'ltr'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
          {t('title')}
        </h1>
        <p className="text-slate-400 text-lg">{t('subtitle')}</p>
      </div>

      {/* Input Form */}
      <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 md:p-8 border border-slate-700">
        <div className="space-y-6">
          {/* Description Input */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              {t('inputLabel')}
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t('inputPlaceholder')}
              className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none h-32"
              dir={isRTL ? 'rtl' : 'ltr'}
            />
          </div>

          {/* Platform Selector */}
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              {t('platformLabel')}
            </label>
            <select
              value={platform}
              onChange={(e) => setPlatform(e.target.value)}
              className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-amber-500"
            >
              <option value="facebook">{t('platforms.facebook')}</option>
              <option value="instagram">{t('platforms.instagram')}</option>
              <option value="tiktok">{t('platforms.tiktok')}</option>
              <option value="twitter">{t('platforms.twitter')}</option>
            </select>
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={loading || !description.trim()}
            className="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-bold rounded-xl transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                {t('generating')}
              </>
            ) : (
              t('generateButton')
            )}
          </button>

          {/* Error Message */}
          {error && (
            <div className="p-4 bg-red-500/20 border border-red-500/50 rounded-xl text-red-300 text-center">
              {error}
            </div>
          )}
        </div>
      </div>

      {/* Results */}
      {result && (
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-amber-400">
            {t('resultsTitle')}
          </h2>

          {/* Image */}
          <div className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700">
            <h3 className="text-lg font-semibold text-white mb-4">{t('imageTitle')}</h3>
            <img
              src={result.imageUrl}
              alt="Generated ad"
              className="w-full rounded-xl mb-4"
              loading="lazy"
            />
            <button
              onClick={() => downloadImage(result.imageUrl, `ad-${result.id}.png`)}
              className="w-full py-3 bg-slate-700 hover:bg-slate-600 text-white rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              {t('downloadButton')}
            </button>
          </div>

          {/* Text Variations */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">{t('textVariations')}</h3>
            <div className="grid gap-4 md:grid-cols-3">
              {result.variations.map((variation, index) => (
                <div key={index} className="bg-slate-800/50 rounded-2xl p-6 border border-slate-700 relative group">
                  <div className={`absolute top-4 ${isRTL ? 'right-4' : 'left-4'} w-8 h-8 bg-amber-500/20 rounded-full flex items-center justify-center text-amber-400 font-bold`}>
                    {index + 1}
                  </div>
                  <p className="text-white mt-8 mb-4 leading-relaxed min-h-[100px]" dir={isRTL ? 'rtl' : 'ltr'}>
                    {variation.text}
                  </p>
                  <button
                    onClick={() => copyToClipboard(variation.text, index)}
                    className={`w-full py-2 ${copiedIndex === index ? 'bg-green-600' : 'bg-slate-700 hover:bg-amber-600'} text-white rounded-lg transition-colors text-sm flex items-center justify-center gap-2`}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                    {copiedIndex === index ? t('copied') : t('copyButton')}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* History */}
      {history.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-amber-400">{t('historyTitle')}</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {history.map((ad) => (
              <button
                key={ad.id}
                onClick={() => loadFromHistory(ad)}
                className="bg-slate-800/30 rounded-xl p-4 border border-slate-700/50 hover:border-amber-500/50 transition-colors text-left"
                dir={isRTL ? 'rtl' : 'ltr'}
              >
                <p className="text-slate-400 text-sm mb-2">
                  {new Date(ad.timestamp).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
                </p>
                <p className="text-white text-sm truncate">
                  {ad.productDescription}
                </p>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}