'use client';

import { useLanguage } from './LanguageContext';

export default function LanguageToggle() {
  const { language, setLanguage, isRTL } = useLanguage();

  return (
    <div className={`flex justify-end mb-6 ${isRTL ? 'rtl' : 'ltr'}`}>
      <div className="flex bg-slate-800 rounded-full p-1 border border-slate-700">
        <button
          onClick={() => setLanguage('ar')}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
            language === 'ar'
              ? 'bg-amber-500 text-white'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          🇸🇦 العربية
        </button>
        <button
          onClick={() => setLanguage('en')}
          className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
            language === 'en'
              ? 'bg-amber-500 text-white'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          🇬🇧 English
        </button>
      </div>
    </div>
  );
}