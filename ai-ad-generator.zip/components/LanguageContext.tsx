'use client';

import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'ar' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const translations = {
  ar: {
    title: 'منشئ إعلانات ذكي',
    subtitle: 'أنشئ إعلانات احترافية بالذكاء الاصطناعي',
    inputLabel: 'صف منتجك/خدمتك',
    inputPlaceholder: 'مثال: قهوة عربية فاخرة من مزرعة اليمن',
    platformLabel: 'نوع الإعلان',
    platforms: {
      facebook: 'فيسبوك',
      instagram: 'إنستغرام',
      tiktok: 'تيك توك',
      twitter: 'تويتر/X'
    },
    generateButton: 'إنشاء الإعلان',
    generating: 'جاري الإنشاء...',
    copyButton: 'نسخ',
    copied: 'تم النسخ!',
    downloadButton: 'تحميل الصورة',
    error: 'حدث خطأ. تأكد من إضافة مفتاح Gemini API.',
    errorNoKey: 'يرجى إضافة مفتاح Gemini API في ملف .env.local',
    historyTitle: 'السجل',
    noHistory: 'لا يوجد سجل بعد',
    resultsTitle: 'النتائج',
    imageTitle: 'الصورة الإعلانية',
    textVariations: 'النسخ الإعلانية',
    disclaimer: 'هذا الموقع يستخدم الذكاء الاصطناعي. المستخدم مسؤول عن المحتوى النهائي. لا نضمن نتائج الإعلانات. الصور من AI وقد تحتاج مراجعة. لا نجمع بيانات مالية.',
    terms: 'الشروط',
    privacy: 'الخصوصية'
  },
  en: {
    title: 'AI Ad Generator',
    subtitle: 'Create professional ads with AI',
    inputLabel: 'Describe your product/service',
    inputPlaceholder: 'e.g., Premium Arabic coffee from Yemen farms',
    platformLabel: 'Ad Type',
    platforms: {
      facebook: 'Facebook',
      instagram: 'Instagram',
      tiktok: 'TikTok',
      twitter: 'Twitter/X'
    },
    generateButton: 'Generate Ad',
    generating: 'Generating...',
    copyButton: 'Copy',
    copied: 'Copied!',
    downloadButton: 'Download Image',
    error: 'An error occurred. Make sure Gemini API key is set.',
    errorNoKey: 'Please add Gemini API key in .env.local file',
    historyTitle: 'History',
    noHistory: 'No history yet',
    resultsTitle: 'Results',
    imageTitle: 'Ad Image',
    textVariations: 'Ad Copies',
    disclaimer: 'This site uses AI. User is responsible for final content. No guarantee on ad results. AI images may need review. No financial data collection.',
    terms: 'Terms',
    privacy: 'Privacy'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('ar');
  const isRTL = language === 'ar';

  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[language];
    for (const k of keys) {
      value = value?.[k];
    }
    return value || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
}