'use client';

import { useLanguage } from './LanguageContext';

export default function Disclaimer() {
  const { t, isRTL } = useLanguage();

  return (
    <footer className={`mt-12 pt-8 border-t border-slate-700/50 ${isRTL ? 'rtl' : 'ltr'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <div className="text-center space-y-4">
        <p className="text-slate-500 text-sm max-w-2xl mx-auto" dir={isRTL ? 'rtl' : 'ltr'}>
          {t('disclaimer')}
        </p>
        <div className="flex justify-center gap-6 text-sm">
          <a href="#" className="text-amber-500 hover:text-amber-400 transition-colors">
            {t('terms')}
          </a>
          <a href="#" className="text-amber-500 hover:text-amber-400 transition-colors">
            {t('privacy')}
          </a>
        </div>
        <p className="text-slate-600 text-xs">
          © 2026 AI Ad Generator. All rights reserved.
        </p>
      </div>
    </footer>
  );
}